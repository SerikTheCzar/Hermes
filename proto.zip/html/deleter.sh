#!/bin/bash


# Set the filename
sudo su
filename='test.txt'

# Create an empty file

touch $filename

# Check the file is exists or not

if [ -f $filename ]; then

   rm test.txt

   echo "$filename is removed"

fi
