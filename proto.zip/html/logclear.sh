#!/bin/sh


rm log.html
touch log.html

chmod -R 777 log.html
