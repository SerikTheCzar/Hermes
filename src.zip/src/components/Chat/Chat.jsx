export const Chat = () => {
    return <>I am chat</>;
};
