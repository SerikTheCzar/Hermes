#!/bin/sh


rm log.html
rm logs.txt
touch log.html
touch logs.txt
chmod -R 777 log.html
chmod -R 777 logs.txt
