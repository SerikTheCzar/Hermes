<?php
if (isset($_POST['submit'])) {
    if (isset($_POST['username']) && isset($_POST['password']) &&
        isset($_POST['gender']) && isset($_POST['email']) && isset($_POST['phone'])) {
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $gender = $_POST['gender'];
        $email = $_POST['email'];
       // $phoneCode = $_POST['phoneCode'];
        $phone = $_POST['phone'];

        $dbname = 'Hermes_Global';
        $dbuser = 'dbmasteruser';
        $dbpass = 'DaytonasStory$123';
        $dbhost = 'ls-303a92f8cfd2da433af284eee07a1052317e9e14.c7xhy47efuuf.ca-central-1.rds.amazonaws.com';
        
        $link = mysqli_connect($dbhost, $dbuser, $dbpass) or die("Unable to Connect to '$dbhost'");
        mysqli_select_db($link, $dbname) or die("Could not open the db '$dbname'");
        
        if ($link->connect_error) {
            die('Could not connect to the database.');
        }
        else {
            $Select = "SELECT email FROM user_test WHERE email = ? LIMIT 1";
            $Insert = "INSERT INTO user_test(username, password, gender, email, phone) values(?, ?, ?, ?, ?)";

            $stmt = $link->prepare($Select);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->bind_result($resultEmail);
            $stmt->store_result();
            $stmt->fetch();
            $rnum = $stmt->num_rows;

            if ($rnum == 0) {
                $stmt->close();

                $stmt = $link->prepare($Insert);
                $stmt->bind_param("ssssi",$username, $password, $gender, $email, $phone);
                if ($stmt->execute()) {
                    echo "New record inserted sucessfully.";
                }
                else {
                    echo $stmt->error;
                }
            }
            else {
                echo "Someone already registers using this email.";
            }
            $stmt->close();
            $link->close();
        }
    }
    else {
        echo "All field are required.";
        die();
    }
}
else {
    echo "Submit button is not set";
}
?>